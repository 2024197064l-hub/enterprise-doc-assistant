import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from uuid import uuid4

from .config import get_settings


def data_path() -> Path:
    base = Path(__file__).resolve().parent.parent / get_settings().data_dir
    base.mkdir(parents=True, exist_ok=True)
    return base


def db_path() -> Path:
    return data_path() / "app.db"


@contextmanager
def connect():
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS documents (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                text TEXT NOT NULL,
                created_at TEXT NOT NULL,
                metadata TEXT NOT NULL DEFAULT '{}'
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chunks (
                id TEXT PRIMARY KEY,
                document_id TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                text TEXT NOT NULL,
                FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS workflows (
                id TEXT PRIMARY KEY,
                payload TEXT NOT NULL
            )
            """
        )


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def save_document(name: str, text: str, chunks: List[str], metadata: Optional[Dict[str, Any]] = None) -> str:
    doc_id = str(uuid4())
    with connect() as conn:
        conn.execute(
            "INSERT INTO documents(id, name, text, created_at, metadata) VALUES (?, ?, ?, ?, ?)",
            (doc_id, name, text, now_iso(), json.dumps(metadata or {}, ensure_ascii=False)),
        )
        for idx, chunk in enumerate(chunks):
            conn.execute(
                "INSERT INTO chunks(id, document_id, chunk_index, text) VALUES (?, ?, ?, ?)",
                (f"{doc_id}:{idx}", doc_id, idx, chunk),
            )
    return doc_id


def list_documents() -> List[Dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute(
            """
            SELECT d.id, d.name, d.created_at, d.metadata, COUNT(c.id) AS chunk_count
            FROM documents d LEFT JOIN chunks c ON d.id = c.document_id
            GROUP BY d.id
            ORDER BY d.created_at DESC
            """
        ).fetchall()
    return [dict(r) | {"metadata": json.loads(r["metadata"] or "{}")} for r in rows]


def delete_document(document_id: str) -> bool:
    with connect() as conn:
        conn.execute("DELETE FROM chunks WHERE document_id = ?", (document_id,))
        cur = conn.execute("DELETE FROM documents WHERE id = ?", (document_id,))
        return cur.rowcount > 0


def list_chunks() -> List[Dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute(
            """
            SELECT c.id AS chunk_id, c.document_id, d.name AS document_name, c.text
            FROM chunks c JOIN documents d ON c.document_id = d.id
            ORDER BY d.created_at DESC, c.chunk_index ASC
            """
        ).fetchall()
    return [dict(r) for r in rows]


def upsert_workflow(template: Dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO workflows(id, payload) VALUES (?, ?)",
            (template["id"], json.dumps(template, ensure_ascii=False)),
        )


def list_workflows() -> List[Dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT payload FROM workflows ORDER BY id ASC").fetchall()
    return [json.loads(r["payload"]) for r in rows]
