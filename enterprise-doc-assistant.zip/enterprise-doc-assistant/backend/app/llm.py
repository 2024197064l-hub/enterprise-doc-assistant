from __future__ import annotations

from typing import List, Optional

import httpx

from .config import get_settings
from .models import SourceChunk
from .retrieval import build_extract_answer


SYSTEM_PROMPT = """你是企业内部文档问答与流程助手。必须遵守：
1. 只基于给定的内部资料回答；资料不足时明确说明缺口。
2. 回答要结构化、可执行，优先给步骤、负责人角色、输入输出、风险点。
3. 引用来源时使用资料编号，例如 [S1]、[S2]。
4. 不编造政策、流程、审批人、日期或 SLA。
5. 用户问流程时，输出：适用场景、前置条件、操作步骤、产出物、风险/例外。
"""


def format_sources(sources: List[SourceChunk]) -> str:
    blocks = []
    for idx, source in enumerate(sources, start=1):
        blocks.append(
            f"[S{idx}] document={source.document_name}, chunk={source.chunk_id}\n{source.text}"
        )
    return "\n\n".join(blocks)


async def generate_answer(question: str, sources: List[SourceChunk]) -> tuple[str, str]:
    settings = get_settings()
    if not settings.openai_api_key:
        return build_extract_answer(question, sources), "local-extractive"

    if not sources:
        return "我还没有检索到可用的内部资料。请先上传相关文档后再提问。", "llm-no-sources"

    payload = {
        "model": settings.openai_model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"内部资料：\n{format_sources(sources)}\n\n用户问题：{question}\n\n请给出中文回答，并在关键结论后标注来源编号。",
            },
        ],
        "temperature": 0.2,
    }
    headers = {"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"}
    url = settings.openai_base_url.rstrip("/") + "/chat/completions"
    async with httpx.AsyncClient(timeout=45) as client:
        response = await client.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
    return data["choices"][0]["message"]["content"], "llm"
