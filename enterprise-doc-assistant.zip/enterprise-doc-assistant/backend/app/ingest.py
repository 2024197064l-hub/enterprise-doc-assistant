from __future__ import annotations

import io
import re
from pathlib import Path
from typing import Iterable, List, Tuple

import pandas as pd
from docx import Document
from pypdf import PdfReader


SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf", ".docx", ".csv", ".xlsx"}


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_text(filename: str, content: bytes) -> Tuple[str, dict]:
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {suffix}. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")

    if suffix in {".txt", ".md"}:
        text = content.decode("utf-8", errors="ignore")
        return normalize_text(text), {"type": suffix[1:]}

    if suffix == ".pdf":
        reader = PdfReader(io.BytesIO(content))
        pages = []
        for i, page in enumerate(reader.pages):
            pages.append(f"[Page {i + 1}]\n{page.extract_text() or ''}")
        return normalize_text("\n\n".join(pages)), {"type": "pdf", "pages": len(reader.pages)}

    if suffix == ".docx":
        doc = Document(io.BytesIO(content))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        tables = []
        for table in doc.tables:
            for row in table.rows:
                tables.append(" | ".join(cell.text.strip() for cell in row.cells))
        return normalize_text("\n".join(paragraphs + tables)), {"type": "docx"}

    if suffix == ".csv":
        df = pd.read_csv(io.BytesIO(content))
        return dataframe_to_text(df, filename), {"type": "csv", "rows": int(len(df)), "columns": list(df.columns)}

    if suffix == ".xlsx":
        excel = pd.ExcelFile(io.BytesIO(content))
        blocks = []
        total_rows = 0
        for sheet in excel.sheet_names:
            df = excel.parse(sheet)
            total_rows += len(df)
            blocks.append(f"# Sheet: {sheet}\n" + dataframe_to_text(df, filename))
        return normalize_text("\n\n".join(blocks)), {"type": "xlsx", "sheets": excel.sheet_names, "rows": total_rows}

    raise ValueError("Unsupported file type")


def dataframe_to_text(df: pd.DataFrame, filename: str) -> str:
    df = df.fillna("")
    max_rows = 1000
    sample = df.head(max_rows)
    lines = [f"# Table extracted from {filename}", "Columns: " + ", ".join(map(str, df.columns))]
    for idx, row in sample.iterrows():
        items = [f"{col}: {row[col]}" for col in df.columns]
        lines.append(f"Row {idx + 1}: " + "; ".join(items))
    if len(df) > max_rows:
        lines.append(f"[Truncated table preview: {max_rows} of {len(df)} rows indexed]")
    return normalize_text("\n".join(lines))


def chunk_text(text: str, chunk_size: int = 900, overlap: int = 160) -> List[str]:
    text = normalize_text(text)
    if not text:
        return []
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: List[str] = []
    current = ""
    for paragraph in paragraphs:
        if len(current) + len(paragraph) + 2 <= chunk_size:
            current = f"{current}\n\n{paragraph}".strip()
        else:
            if current:
                chunks.append(current)
            if len(paragraph) <= chunk_size:
                current = paragraph
            else:
                start = 0
                while start < len(paragraph):
                    chunks.append(paragraph[start : start + chunk_size])
                    start += max(1, chunk_size - overlap)
                current = ""
    if current:
        chunks.append(current)
    return chunks
