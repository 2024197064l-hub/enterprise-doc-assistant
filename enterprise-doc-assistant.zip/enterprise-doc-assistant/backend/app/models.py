from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional


class SourceChunk(BaseModel):
    document_id: str
    document_name: str
    chunk_id: str
    text: str
    score: float


class AskRequest(BaseModel):
    question: str = Field(..., min_length=1)
    top_k: int = Field(5, ge=1, le=12)
    workflow: Optional[str] = None


class AskResponse(BaseModel):
    answer: str
    sources: List[SourceChunk]
    workflow_suggestion: Optional[Dict[str, Any]] = None
    mode: str


class DocumentInfo(BaseModel):
    id: str
    name: str
    created_at: str
    chunk_count: int
    metadata: Dict[str, Any] = {}


class WorkflowTemplate(BaseModel):
    id: str
    name: str
    description: str
    trigger_keywords: List[str]
    steps: List[str]
    output_fields: List[str]
