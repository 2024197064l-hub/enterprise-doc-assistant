from __future__ import annotations

from typing import Any, Dict, List, Optional

from .storage import list_workflows, upsert_workflow


DEFAULT_WORKFLOWS = [
    {
        "id": "it-support",
        "name": "IT 支持/故障处理",
        "description": "用于账号、设备、网络、权限、系统故障等内部支持问题。",
        "trigger_keywords": ["账号", "登录", "权限", "网络", "电脑", "系统", "故障", "打不开", "IT"],
        "steps": [
            "确认影响范围：单人/多人、单系统/多系统。",
            "收集必要信息：用户、系统名、报错截图、发生时间、复现步骤。",
            "检索相关 SOP 或 FAQ，先执行可逆的自助排查步骤。",
            "无法解决时创建工单，标注影响等级和紧急程度。",
            "跟踪关闭：记录根因、修复动作和预防建议。",
        ],
        "output_fields": ["问题摘要", "影响范围", "已尝试步骤", "建议处理路径", "是否需要升级"],
    },
    {
        "id": "purchase-approval",
        "name": "采购/付款审批",
        "description": "用于采购申请、供应商、合同、发票、付款流程咨询。",
        "trigger_keywords": ["采购", "付款", "报销", "发票", "供应商", "合同", "审批", "预算"],
        "steps": [
            "确认采购类型、金额、预算归属和业务必要性。",
            "核对供应商准入、合同或报价材料是否齐全。",
            "根据金额和部门规则识别审批链。",
            "生成申请说明，附合同、报价、验收或发票材料。",
            "审批后进入下单、验收、付款或归档环节。",
        ],
        "output_fields": ["申请事项", "金额/预算", "必需材料", "审批路径", "风险提醒"],
    },
    {
        "id": "hr-policy",
        "name": "人事政策/员工服务",
        "description": "用于请假、入离职、考勤、福利、绩效等 HR 政策问答。",
        "trigger_keywords": ["请假", "入职", "离职", "考勤", "绩效", "福利", "社保", "人事", "HR"],
        "steps": [
            "确认员工类型、地区、适用政策版本和时间范围。",
            "检索制度条款，区分强制规则和例外处理。",
            "给出申请入口、材料清单和审批角色。",
            "提示截止日期、合规风险或需要 HR 人工确认的例外。",
            "生成可复制的申请说明或咨询工单内容。",
        ],
        "output_fields": ["适用政策", "申请步骤", "所需材料", "审批角色", "例外/风险"],
    },
]


def seed_defaults() -> None:
    existing = {w["id"] for w in list_workflows()}
    for wf in DEFAULT_WORKFLOWS:
        if wf["id"] not in existing:
            upsert_workflow(wf)


def suggest_workflow(question: str, preferred_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    workflows = list_workflows()
    if preferred_id:
        for wf in workflows:
            if wf["id"] == preferred_id:
                return wf
    q = question.lower()
    scored = []
    for wf in workflows:
        score = sum(1 for kw in wf.get("trigger_keywords", []) if kw.lower() in q)
        if score:
            scored.append((score, wf))
    if not scored:
        return None
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[0][1]
