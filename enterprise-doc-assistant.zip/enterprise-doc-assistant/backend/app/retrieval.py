from __future__ import annotations

import re
from typing import Dict, List

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .models import SourceChunk
from .storage import list_chunks


class Retriever:
    def search(self, question: str, top_k: int = 5) -> List[SourceChunk]:
        rows = list_chunks()
        if not rows:
            return []
        corpus = [r["text"] for r in rows]
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=20000)
        matrix = vectorizer.fit_transform(corpus)
        q = vectorizer.transform([question])
        scores = cosine_similarity(q, matrix).flatten()
        ranked = np.argsort(scores)[::-1][:top_k]
        results: List[SourceChunk] = []
        for idx in ranked:
            row = rows[int(idx)]
            results.append(
                SourceChunk(
                    document_id=row["document_id"],
                    document_name=row["document_name"],
                    chunk_id=row["chunk_id"],
                    text=row["text"],
                    score=float(scores[int(idx)]),
                )
            )
        return results


def build_extract_answer(question: str, sources: List[SourceChunk]) -> str:
    if not sources:
        return "我还没有检索到可用的内部文档。请先上传制度、SOP、项目说明、FAQ 或流程文档。"
    sentences = []
    q_terms = set(re.findall(r"[\w\u4e00-\u9fff]+", question.lower()))
    for source in sources:
        for sent in re.split(r"(?<=[。！？.!?])\s+|\n", source.text):
            clean = sent.strip()
            if len(clean) < 12:
                continue
            terms = set(re.findall(r"[\w\u4e00-\u9fff]+", clean.lower()))
            overlap = len(q_terms & terms)
            sentences.append((overlap, source.score, clean, source.document_name))
    sentences.sort(key=lambda x: (x[0], x[1], len(x[2])), reverse=True)
    picked = []
    seen = set()
    for _, _, sent, doc in sentences:
        key = sent[:80]
        if key in seen:
            continue
        seen.add(key)
        picked.append(f"- {sent}（来源：{doc}）")
        if len(picked) >= 5:
            break
    if not picked:
        picked = [f"- {s.text[:500]}（来源：{s.document_name}）" for s in sources[:3]]
    return "基于已上传内部文档，我能确认的要点如下：\n\n" + "\n".join(picked) + "\n\n建议：如需更完整的生成式回答，请在 backend/.env 中配置 OPENAI_API_KEY。"
