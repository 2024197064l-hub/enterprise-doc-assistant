from __future__ import annotations

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .config import get_settings
from .ingest import chunk_text, extract_text
from .llm import generate_answer
from .models import AskRequest, AskResponse, DocumentInfo, WorkflowTemplate
from .retrieval import Retriever
from .storage import delete_document, init_db, list_documents, save_document
from .workflows import seed_defaults, suggest_workflow

app = FastAPI(title="Enterprise Document Assistant", version="1.0.0")
settings = get_settings()

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.app_cors_origin, "http://localhost:3000", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup() -> None:
    init_db()
    seed_defaults()


@app.get("/health")
def health():
    return {"ok": True, "mode": "llm" if settings.openai_api_key else "local-extractive"}


@app.post("/documents", response_model=DocumentInfo)
async def upload_document(file: UploadFile = File(...)):
    content = await file.read()
    try:
        text, metadata = extract_text(file.filename or "uploaded.txt", content)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    chunks = chunk_text(text)
    if not chunks:
        raise HTTPException(status_code=400, detail="No readable text was extracted from this file.")
    doc_id = save_document(file.filename or "uploaded", text, chunks, metadata)
    return DocumentInfo(id=doc_id, name=file.filename or "uploaded", created_at="just now", chunk_count=len(chunks), metadata=metadata)


@app.get("/documents", response_model=list[DocumentInfo])
def documents():
    return list_documents()


@app.delete("/documents/{document_id}")
def remove_document(document_id: str):
    ok = delete_document(document_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"ok": True}


@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest):
    retriever = Retriever()
    sources = retriever.search(req.question, top_k=req.top_k)
    answer, mode = await generate_answer(req.question, sources)
    workflow = suggest_workflow(req.question, req.workflow)
    return AskResponse(answer=answer, sources=sources, workflow_suggestion=workflow, mode=mode)


@app.get("/workflows", response_model=list[WorkflowTemplate])
def workflows():
    from .storage import list_workflows

    return list_workflows()
