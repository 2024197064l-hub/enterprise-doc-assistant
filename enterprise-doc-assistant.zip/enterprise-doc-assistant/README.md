# 企业内部文档问答与流程助手 MVP

这是一个完整可运行的企业内部 AI 项目：上传内部文档后，系统会进行文档解析、切分、检索增强问答，并根据问题自动建议流程模板。

## 功能

- 支持上传 `.txt`、`.md`、`.pdf`、`.docx`、`.csv`、`.xlsx`
- 本地 TF-IDF 检索，不需要向量数据库即可运行
- 可选 OpenAI 兼容 LLM：配置 API Key 后自动生成更自然的 RAG 回答
- 自动显示引用片段，便于追溯来源
- 内置流程助手模板：IT 支持、采购审批、HR 政策
- React 前端 + FastAPI 后端 + SQLite 数据库

## 一键运行：Docker Compose

```bash
cd enterprise-doc-assistant
cp backend/.env.example backend/.env
# 可选：编辑 backend/.env，填入 OPENAI_API_KEY

docker compose up --build
```

打开：

- 前端：http://localhost:5173
- 后端 API：http://localhost:8000/docs

## 本地开发运行

### 后端

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

### 前端

```bash
cd frontend
npm install
npm run dev
```

## 使用方式

1. 打开前端页面。
2. 上传 `sample_docs` 目录中的示例文档，或上传你的内部制度、SOP、FAQ、项目文档。
3. 输入问题，例如：
   - 采购 3 万元的软件订阅需要哪些审批？
   - 系统登录失败应该怎么处理？
   - 年假申请需要提前多久？
4. 查看回答、引用片段和流程建议。

## LLM 配置

默认不需要 API Key，系统会使用本地检索式回答。如果想启用真正的生成式 RAG，请编辑 `backend/.env`：

```env
OPENAI_API_KEY=你的 key
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```

也可以替换成任何 OpenAI-compatible endpoint。

## 项目结构

```text
enterprise-doc-assistant/
├── backend/
│   ├── app/
│   │   ├── main.py          # FastAPI 入口
│   │   ├── ingest.py        # 文档解析与切分
│   │   ├── retrieval.py     # TF-IDF 检索
│   │   ├── llm.py           # OpenAI 兼容 LLM 调用与本地 fallback
│   │   ├── workflows.py     # 流程助手模板和匹配
│   │   ├── storage.py       # SQLite 存储
│   │   └── models.py        # API 模型
│   └── requirements.txt
├── frontend/
│   └── src/
│       ├── main.jsx
│       └── styles.css
├── sample_docs/
├── docker-compose.yml
└── README.md
```

## 下一步可扩展方向

- 把 TF-IDF 替换为 pgvector、Qdrant、Milvus 或 Chroma
- 增加用户登录、部门权限、文档 ACL
- 增加工单系统、企业微信、飞书、Slack、Jira 集成
- 增加流程模板后台配置
- 增加答案评价、引用审核、日志审计
- 增加 OCR 和图片/PPT 解析
