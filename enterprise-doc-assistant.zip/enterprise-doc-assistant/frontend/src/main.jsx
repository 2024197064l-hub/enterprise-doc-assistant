import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Upload, Send, FileText, Trash2, Workflow, Bot, Database } from 'lucide-react';
import './styles.css';

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

function App() {
  const [docs, setDocs] = useState([]);
  const [workflows, setWorkflows] = useState([]);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  async function refresh() {
    const [d, w] = await Promise.all([
      fetch(`${API}/documents`).then(r => r.json()),
      fetch(`${API}/workflows`).then(r => r.json())
    ]);
    setDocs(d);
    setWorkflows(w);
  }

  useEffect(() => { refresh().catch(e => setError(String(e))); }, []);

  async function onUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true); setError('');
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch(`${API}/documents`, { method: 'POST', body: form });
      if (!res.ok) throw new Error((await res.json()).detail || '上传失败');
      await refresh();
    } catch (err) { setError(err.message); }
    finally { setUploading(false); e.target.value = ''; }
  }

  async function ask() {
    if (!question.trim()) return;
    setLoading(true); setError(''); setAnswer(null);
    try {
      const res = await fetch(`${API}/ask`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, top_k: 6 })
      });
      if (!res.ok) throw new Error((await res.json()).detail || '提问失败');
      setAnswer(await res.json());
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function removeDoc(id) {
    await fetch(`${API}/documents/${id}`, { method: 'DELETE' });
    await refresh();
  }

  return <div className="page">
    <header className="hero">
      <div>
        <div className="eyebrow"><Bot size={18}/> Enterprise AI MVP</div>
        <h1>企业内部文档问答与流程助手</h1>
        <p>上传制度、SOP、项目说明、FAQ、表格或合同，系统会进行检索增强问答，并根据问题自动建议流程路径。</p>
      </div>
      <label className="uploadBtn">
        <Upload size={18}/>{uploading ? '上传中...' : '上传文档'}
        <input type="file" onChange={onUpload} accept=".txt,.md,.pdf,.docx,.csv,.xlsx" />
      </label>
    </header>

    {error && <div className="error">{error}</div>}

    <main className="grid">
      <section className="card askPanel">
        <h2><Send size={20}/> 提问</h2>
        <textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="例如：采购 3 万元的软件订阅需要走什么审批？请假流程需要哪些材料？系统登录失败应该怎么处理？" />
        <button className="primary" onClick={ask} disabled={loading || docs.length === 0}>{loading ? '分析中...' : '发送问题'}</button>
        {docs.length === 0 && <p className="hint">请先上传至少一份内部文档。你也可以使用 sample_docs 里的示例文档。</p>}

        {answer && <div className="answer">
          <div className="mode">回答模式：{answer.mode}</div>
          <MarkdownText text={answer.answer}/>
          {answer.workflow_suggestion && <div className="workflowBox">
            <h3><Workflow size={18}/> 建议流程：{answer.workflow_suggestion.name}</h3>
            <p>{answer.workflow_suggestion.description}</p>
            <ol>{answer.workflow_suggestion.steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
          </div>}
          <h3>引用片段</h3>
          <div className="sources">{answer.sources.map((s, i) => <details key={s.chunk_id}>
            <summary>[S{i+1}] {s.document_name} · score {s.score.toFixed(3)}</summary>
            <pre>{s.text}</pre>
          </details>)}</div>
        </div>}
      </section>

      <aside className="side">
        <section className="card">
          <h2><Database size={20}/> 文档库</h2>
          {docs.length === 0 ? <p className="muted">暂无文档</p> : docs.map(d => <div className="doc" key={d.id}>
            <FileText size={18}/><div><b>{d.name}</b><span>{d.chunk_count} chunks</span></div>
            <button className="icon" onClick={() => removeDoc(d.id)}><Trash2 size={16}/></button>
          </div>)}
        </section>
        <section className="card">
          <h2><Workflow size={20}/> 内置流程模板</h2>
          {workflows.map(w => <div className="wf" key={w.id}><b>{w.name}</b><p>{w.description}</p></div>)}
        </section>
      </aside>
    </main>
  </div>
}

function MarkdownText({ text }) {
  return <div className="markdown">{text.split('\n').map((line, i) => {
    if (line.startsWith('### ')) return <h3 key={i}>{line.slice(4)}</h3>;
    if (line.startsWith('## ')) return <h2 key={i}>{line.slice(3)}</h2>;
    if (line.startsWith('- ')) return <p key={i} className="bullet">• {line.slice(2)}</p>;
    if (/^\d+\. /.test(line)) return <p key={i} className="bullet">{line}</p>;
    return line ? <p key={i}>{line}</p> : <br key={i}/>;
  })}</div>
}

createRoot(document.getElementById('root')).render(<App />);
